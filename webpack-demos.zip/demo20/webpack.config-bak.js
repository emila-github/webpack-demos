var path = require('path')
  , glob = require("glob")
  , webpack = require("webpack")
  , __DEV__ = process.env.NODE_ENV !== 'production'
  , src_root = 'source'
  , dist_root = 'build';

//var entrys = [];
//glob.sync(path.join(src_root, './**/*.entry.js')).map(function(entryPath) {
//  var entryName = path.basename(entryPath, '.entry.js');
//  entrys[entryName] =  entryPath
//});
//console.log(src_root,dist_root, entrys)

var entrys= {index: './source/js/index.entry.js'};


module.exports = {
//  entry: './*.entry.js',
  entry: entrys,
  output: {
    path: path.resolve(__dirname, dist_root),
    filename: '[name].bundle.js'
  },
  module: {
    loaders:[
      { test: /\.css$/, loader: 'style-loader!css-loader' },
      { test: /\.js[x]?$/, exclude: /node_modules/, loader: 'babel-loader?presets[]=es2015&presets[]=react' },
    ]
  }
};



//module.exports = glob.sync(path.join(src_root, './**/*.entry.js'))
//  .map(function(entryPath) {
//
//    var entryName = path.basename(entryPath, '.entry.js')
//      , relativeEntryPath = path.relative(src_root, entryPath)
//      , outputPath = path.join(__DEV__ ? src_root : dist_root, relativeEntryPath, '../')
//    console.log('entryPath=', entryPath, entryName);
//    console.log('relativeEntryPath=', relativeEntryPath);
//    console.log('outputPath=', outputPath);
//    return {
//      entry: {
//        [entryName]: entryPath
//  }
//  , resolve: {
//  root: path.join(src_root, './js')
//
//}
//, output: {
//  path: outputPath
//    , filename: '[name].bundle.js'
//}
//, module: {
//  loaders: [
//    { test: /\.handlebars$/
//      , loader: "handlebars-loader"
//    }
//  ]
//}
//
//}
//})
